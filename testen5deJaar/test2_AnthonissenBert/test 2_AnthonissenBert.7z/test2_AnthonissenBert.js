﻿console.log("-- Test 2 --");
console.log();

function BerekenSom(getal) {
    for (var i = 1; i <= getal; i++) {
    }
    return i;
}

BerekenSom(7);
BerekenSom(5);

/*
for (var i = 1; i <= 10; i++) {
    console.log(i * 10);
}
*/

/*
var voornaam = "Bert";
var achternaam = "Anthonissen";

console.log(voornaam + " " + achternaam);
*/

/*
var getal = 3.25

if (getal > 20) {
    console.log(2 + getal);
} else {
    console.log(getal - 5);
}

*/
